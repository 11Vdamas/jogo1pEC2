package com.mycompany.jogo2;

import java.util.Random;

/**
 *
 * @author yslan
 */
class Personagem {
    private Armadura armadura;
    private String nome;
    private int pontosDeVida;
    private int forca;
    private int defesa;
    private int agilidade;
    private int destreza;
    private int constanteDano;
    private int categoriaarma;
    private int categoriaarmadura;

    private static final int PONTOS_DE_VIDA_BASE = 6;
    private static final int VIDA_MAXIMA = 70;

    public Personagem(String nome, int forca, int defesa, int agilidade, int destreza, int categoriaarma, int categoriaarmadura) {
        this.nome = nome;
        this.forca = forca;
        this.defesa = defesa;
        this.agilidade = agilidade;
        this.destreza = destreza;
        this.defesa = defesa;
        this.pontosDeVida = calcularPontosDeVida();
        this.categoriaarma = categoriaarma;
        this.categoriaarmadura = categoriaarmadura;
    }


    private int calcularPontosDeVida() {
        Random random = new Random();
        int somaDados = random.nextInt(6) + 1 + random.nextInt(6) + 1 + random.nextInt(6) + 1;
        int pontosDeVidaCalculados = somaDados + (2 * defesa) + PONTOS_DE_VIDA_BASE;

        // Limita a vida máxima a 70
        return Math.min(pontosDeVidaCalculados, VIDA_MAXIMA);
    }

    public int getPontosDeVida() {
        return pontosDeVida;
    }

    public int getForca() {
        return forca;
    }

    public int getDefesa() {
        return defesa;
    }

    public int getAgilidade() {
        return agilidade;
    }

    public int getDestreza() {
        return destreza;
    }

    public void setPontosDeVida(int pontosDeVida) {
        this.pontosDeVida = pontosDeVida;
    }

    public int atacar() {
        int dano;

        return dano = forca;
    }

    public void dobrarDefesa() {
        // Dobra a defesa do personagem por um turno
        defesa *= 2;
    }

    public String getNome() {
        return nome;
    }

    public int getVidaMaxima() {
        return VIDA_MAXIMA;
    }

    private void setForca(int forca) {
        this.forca = forca;
    }

    private int setDefesa(int Defesa) {
        this.defesa = defesa;
        return defesa;
    }

    void setDestreza(int pontosDestreza) {
        this.destreza += pontosDestreza;
    }

    private void setAgilidade(int i) {
        this.agilidade = agilidade;
    }
public void aumentarDefesa(int pontos) {
        this.defesa += pontos;
    }

    public void aumentarfroca(int pontos) {
        this.forca += pontos;
    }

    void aumentarAgilidade(int pontosAgilidade) {
        this.agilidade += pontosAgilidade;
    }

    void aumentarDestreza(int pontosDestreza) {
        this.destreza += pontosDestreza;
    }

    void aumentarForca(int pontosForca) {
        this.forca += pontosForca;
    }

    
}
