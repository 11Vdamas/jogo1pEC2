package com.mycompany.jogo2;

import java.util.Random;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Jogo2 {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.iniciar();

    }
}

class Menu {

    private final Scanner scanner;
    private final Random random;
    private Personagem personagem;
    private Arma arma;
    private Armadura armadura;

    public Menu() {
        scanner = new Scanner(System.in);
        random = new Random();
    }

    public void iniciar() {
        int escolha;

        do {
            exibirOpcoesMenu();
            escolha = lerInteiro();

            switch (escolha) {
                case 1:
                    personagem = criarPersonagem();
                    jogar();
                    break;
                case 2:
                    mostrarHistoria();
                    break;
                case 3:
                    System.out.println("Saindo do jogo. Até a próxima!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (escolha != 3);
    }

    private void exibirOpcoesMenu() {
        System.out.println("======================");
        System.out.println("        MENU");
        System.out.println("     1. Jogar");
        System.out.println("     2. História");
        System.out.println("     3. Sair");
        System.out.println("======================");
        System.out.print("Escolha uma opção: ");
    }

    private void jogar() {
        if (personagem == null) {
            System.out.println("Crie um personagem antes de jogar.");
            return;
        }

        int nivel = 1;
        boolean jogadorVenceu = false;

        while (nivel <= 3) { // Dois níveis no jogo
            System.out.println("\n======= Nível " + nivel + " =======");
            int pocoesRestantesJogador = 3;
            int pocoesInimigo = 0;

            Inimigo inimigo = inimigoAleatorio(personagem, nivel);
            System.out.println("\n==============================================");
            System.out.println("Você está lutando contra " + inimigo.getNome() + "!");
            System.out.println("HP: " + inimigo.getPontosDeVida());
            System.out.println("Força: " + inimigo.getDano());
            System.out.println("Agilidade: " + inimigo.getAgilidade());
            System.out.println("Defesa: " + inimigo.getDefesa());
            System.out.println("===============================================");
            System.out.println("\nVocê está jogando com o personagem: " + personagem.getNome());
            System.out.println("HP: " + personagem.getPontosDeVida());
            System.out.println("Força: " + personagem.getForca());
            System.out.println("Defesa: " + personagem.getDefesa());
            System.out.println("Agilidade: " + personagem.getAgilidade());
            System.out.println("Destreza: " + personagem.getDestreza());
            System.out.println("===============================================");

            int escolhaAcao;

            while (true) {
                System.out.println("\n--- Rodada ---");
                exibirOpcoesAcao();

                try {
                    escolhaAcao = lerInteiro();
                } catch (InputMismatchException e) {
                    System.out.println("Entrada inválida. Digite um número válido.");
                    scanner.next();
                    continue;
                }

                switch (escolhaAcao) {
                    case 1:
                        int danoDoJogador = personagem.atacar();
                        int danoRecebido = inimigo.getcalcularDano();
                        int danoInfligido = Math.max(0, danoDoJogador - inimigo.getDefesa());
                        int danoSofrido = Math.max(0, danoRecebido - personagem.getDefesa());

                        personagem.setPontosDeVida(personagem.getPontosDeVida() - danoSofrido);

                        inimigo.setPontosDeVida(inimigo.getPontosDeVida() - danoInfligido);

                        exibirResultadoBatalha(inimigo, personagem, danoInfligido, danoSofrido);
                        break;

                    case 2:
                        personagem.dobrarDefesa();
                        System.out.println("Você dobrou sua defesa neste turno.");
                        break;
                    case 3:
                        if (pocoesRestantesJogador > 0) {
                            int cura = usarPocao();
                            personagem.setPontosDeVida(personagem.getPontosDeVida() + cura);
                            pocoesRestantesJogador--;

                            System.out.println("Você se curou em " + cura + " pontos de vida.");
                        } else {
                            System.out.println("Você não tem mais poções disponíveis.");
                        }
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                        break;
                }

                // Turno do adversário
                int acaoAdversario = random.nextInt(3);

                switch (acaoAdversario) {
                    case 0:
                        int danoDoInimigo = inimigo.calcularDano();
                        int danoRecebidoDoInimigo = Math.max(0, personagem.atacar() - personagem.getDefesa());
                        personagem.setPontosDeVida(personagem.getPontosDeVida() - danoRecebidoDoInimigo);
                        exibirResultadoBatalha(inimigo, personagem, danoRecebidoDoInimigo, danoDoInimigo);

                        break;
                    case 1:
                        inimigo.Defesa();
                        System.out.println(inimigo.getNome() + " dobrou sua defesa neste turno.");
                        break;
                    case 2:
                        if (pocoesInimigo < 3) { // Limite de 3 poções para o inimigo
                            int cura = usarPocao();
                            inimigo.setPontosDeVida(inimigo.getPontosDeVida() + cura);
                            pocoesInimigo++;
                            System.out.println(inimigo.getNome() + " usou uma poção e se curou em " + cura + " pontos de vida.");
                        }
                        break;
                }

                if (inimigo.getPontosDeVida() <= 0 && nivel < 3) {
                    jogadorVenceu = true;
                    System.out.println("Você venceu a batalha contra " + inimigo.getNome() + "!");

                    // Mostrar a mensagem de bônus
                    System.out.println("=====================================================");
                    System.out.println("         VOCÊ RECEBEU UM BÔNUS DA VITÓRIA!");
                    System.out.println("=====================================================");

                    // Distribuição de pontos de atributo
                    int pontosDisponiveis = 20;

                    while (pontosDisponiveis > 0) {

                        System.out.println("Pontos disponíveis para distribuir: " + pontosDisponiveis);
                        System.out.println("*Você só pode distribuir até 2 pontos por atributo");

                        System.out.print("Adicione pontos em Força (Pontos restantes: " + pontosDisponiveis);
                        int pontosForca = lerInteiro();
                        if (pontosForca <= 10 && pontosForca <= pontosDisponiveis) {
                            personagem.aumentarForca(pontosForca);
                            pontosDisponiveis -= pontosForca;
                        } else {
                            System.out.println("Pontuação inválida. Tente novamente.");
                            continue;
                        }

                        System.out.print("Adicione pontos em Defesa (Pontos restantes: " + pontosDisponiveis);
                        int pontosConstituicao = lerInteiro();
                        if (pontosConstituicao <= 10 && pontosConstituicao <= pontosDisponiveis) {
                            personagem.aumentarDefesa(pontosConstituicao);
                            pontosDisponiveis -= pontosConstituicao;
                        } else {
                            System.out.println("Pontuação inválida. Tente novamente.");
                            continue;
                        }

                        System.out.print("Adicione pontos em Agilidade (Pontos restantes: " + pontosDisponiveis);
                        int pontosAgilidade = lerInteiro();
                        if (pontosAgilidade <= 10 && pontosAgilidade <= pontosDisponiveis) {
                            personagem.aumentarAgilidade(pontosAgilidade);
                            pontosDisponiveis -= pontosAgilidade;
                        } else {
                            System.out.println("Pontuação inválida. Tente novamente.");
                            continue;
                        }
                        System.out.print("Adicione pontos em Destreza (Pontos restantes: " + pontosDisponiveis);
                        int pontosDestreza = lerInteiro();
                        if (pontosDestreza <= 10 && pontosDestreza <= pontosDisponiveis) {
                            personagem.aumentarDestreza(pontosDestreza);
                            pontosDisponiveis -= pontosDestreza;
                        } else {
                            System.out.println("Pontuação inválida. Tente novamente.");
                            continue;
                        }

                        break; // Sai do loop se a distribuição de pontos for válida
                    }

                    // colocar aqui o bonus!!!!
                    break; // Sai do loop, pois o inimigo está derrotado
                } else if (personagem.getPontosDeVida() <= 0) {
                    jogadorVenceu = false;
                    System.out.println("Você foi derrotado por " + inimigo.getNome() + ". Game over!");
                    break; // Sai do loop, pois o jogador está derrotado
                }

            }

            nivel++;
        }

    }

    private void exibirOpcoesAcao() {
        System.out.println("Ações disponíveis:");
        System.out.println("1. Atacar");
        System.out.println("2. Defender");
        System.out.println("3. Usar Poção");

        System.out.print("Escolha uma ação: ");
    }

    private int usarPocao() {
        int cura = random.nextInt(6) + 1 + random.nextInt(6) + 1 + random.nextInt(6) + 1;
        return cura;
    }

    private void exibirResultadoBatalha(Inimigo inimigo, Personagem jogador, int danoJogador, int danoInimigo) {
        System.out.println("Você ataca e causa " + danoJogador + " pontos de dano em " + inimigo.getNome() + ".");
        System.out.println(inimigo.getNome() + " ataca e causa " + danoInimigo + " pontos de dano em você.");
        System.out.println("Status do " + jogador.getNome() + ": Pontos de Vida = " + jogador.getPontosDeVida());
        System.out.println("Status do " + inimigo.getNome() + ": Pontos de Vida = " + inimigo.getPontosDeVida());
    }

    private void mostrarHistoria() {
        System.out.println("/,--.----------------------------------------------------------------------------------------------,\\");
        System.out.println("|   /,--.                                                                                           |");
        System.out.println("|  /      `--,                                                                                      |");
        System.out.println("| |       _,--`.                                                                                ,-  |");
        System.out.println("|  \\,---'      `--'--,,--,,--,,-'--'--,,--,,--,,-`--'--,,--,,- ,--,,--,,--,,-`-,-`--'--,,--,,- |");
        System.out.println("|                                                                                                   |");
        System.out.println("|  Em um tranquilo bairro de Belém, um jovem paraense vive uma vida comum e tomando seu açaí de boa,|");
        System.out.println("| até que descobre que possui habilidades mágicas. Sua vida muda drasticamente quando é convidado   |");
        System.out.println("| para se matricular na misteriosa Escola de Magia da Ilha Mística situada em uma ilha no           |");
        System.out.println("| arquipélago de Belém.                                                                             |");
        System.out.println("|                                                                                                   |");
        System.out.println("| Entretanto, a paz da ilha é abalada quando ela é atacada por uma horda de terríveis               |");
        System.out.println("| criaturas, todas elas personagens das lendas urbanas do Brasil. O campus                          |");
        System.out.println("| da escola se transforma em um labirinto sombrio, onde monstros rondam cada corredor e sala        |");
        System.out.println("| de aula. O protagonista e seus novos amigos mágicos se veem encurralados, incapazes de            |");
        System.out.println("|  escapar da ilha. No entanto, há uma única saída que permanece desbloqueada, mas para alcançá-la, |");
        System.out.println("| eles devem enfrentar o desafio mais assustador de suas vidas. A saída é guardada por um           |");
        System.out.println("| terrível chefão, uma criatura lendária que personifica o medo que as histórias urbanas do         |");
        System.out.println("| Brasil inspiram.                                                                                  |");
        System.out.println("|                                                                                                   |");
        System.out.println("| A jornada do protagonista e seus amigos é uma busca pela coragem, determinação e confiança        |");
        System.out.println("| em suas habilidades mágicas recém-descobertas. Eles deverão lutar contra as próprias lendas       |");
        System.out.println("| que assombraram suas infâncias, superando os monstros que emergem das sombras, e finalmente       |");
        System.out.println("| enfrentar o temível chefão para escapar da ilha e salvar a escola. 2Esta é uma aventura           |");
        System.out.println("| emocionante, repleta de referências à rica mitologia brasileira, que mergulha os jogadores        |");
        System.out.println("| em um mundo onde o folclore se torna realidade, e a coragem do protagonista é posta à prova       |");
        System.out.println("| em uma batalha épica pela sobrevivência e liberdade.                                              |");
        System.out.println("|                                                                                                   |");
        System.out.println("'--,,--,,--,,-'--'--,,--,,--,,-`--'--,,--,,- ,--,'--,,`--'--,,---,,--,,--,,-`--,,--,,-`--'--,,--,,--|");

    }

    private Personagem criarPersonagem() {
        System.out.println("\n==========================================================================================================");
        System.out.println("\n                                    *29 DE FEVEREIRO DE 1912*\n");
        System.out.println("''Eu sempre me achei uma pessoa muito estranha e não tenho muitos amigos também''\n");
        System.out.println("''Bom, todos fazem piadas sobre meu aniversário''\n");
        System.out.println("''Não posso julga-los, pois nasci em um ano bissexto''\n");
        System.out.println("''Sempre achei isso algo ruim e irritante, pois minha mãe só faziam meu aniversário\n de 4 em 4 anos''\n");
        System.out.println("''Até que...tudo mudou em minha vida...''\n");
        System.out.println("==========================================================================================================");
        System.out.print("\nDigite o nome do seu personagem: ");
        String nome = scanner.next();

        int pontosDisponiveis = 15;
        int forca = 0, defesa = 0, agilidade = 0, destreza = 0;

        while (pontosDisponiveis > 0) {
            System.out.println("Pontos disponíveis para distribuir: " + pontosDisponiveis);

            System.out.print("Distribua pontos em Força (max 10 pontos): ");
            int pontosForca = scanner.nextInt();
            if (pontosForca <= 10 && pontosForca <= pontosDisponiveis) {
                forca = pontosForca;
                pontosDisponiveis -= pontosForca;
            } else {
                System.out.println("Pontuação inválida. Tente novamente.");
                continue;
            }

            System.out.print("Distribua pontos em Defesa (max " + pontosDisponiveis + " pontos):");
            int pontosConstituicao = scanner.nextInt();
            if (pontosConstituicao <= 10 && pontosConstituicao <= pontosDisponiveis) {
                defesa = pontosConstituicao;
                pontosDisponiveis -= pontosConstituicao;
            } else {
                System.out.println("Pontuação inválida. Tente novamente.");
                continue;
            }

            System.out.print("Distribua pontos em Agilidade (max " + pontosDisponiveis + " pontos):");
            int pontosAgilidade = scanner.nextInt();
            if (pontosAgilidade <= 10 && pontosAgilidade <= pontosDisponiveis) {
                agilidade = pontosAgilidade;
                pontosDisponiveis -= pontosAgilidade;
            } else {
                System.out.println("Pontuação inválida. Tente novamente.");
                continue;
            }

            System.out.print("Distribua pontos em Destreza (max " + pontosDisponiveis + " pontos):");
            int pontosDestreza = scanner.nextInt();
            if (pontosDestreza <= 10 && pontosDestreza <= pontosDisponiveis) {
                destreza = pontosDestreza;
                pontosDisponiveis -= pontosDestreza;
            } else {
                System.out.println("Pontuação inválida. Tente novamente.");
                continue;
            }

            break; // Sai do loop se a distribuição de pontos for válida
        }

        int categoriaarmadura;
        int categoriaarma;
        do {
            System.out.printf("\n===================\n");
            System.out.printf("   (1) Escova\n");
            System.out.printf("   (2) Varinha\n");
            System.out.printf("   (3) Cajado\n");
            System.out.printf("===================");
            System.out.printf("\nEscolha sua arma:");
            categoriaarma = scanner.next().charAt(0);
            categoriaarma = Character.toUpperCase(categoriaarma); // Converte para maiúsculas para consistência
            switch (categoriaarma) {
                case 1:
                    arma.calcularDanoEscova();
                    break;
                case 2:
                    arma.calcularDanoVarinha();
                    break;
                case 3:
                    arma.calcularDanoCajado();
                    break;
                default:
                    break;
            }

        } while (categoriaarma != '2' && categoriaarma != '1' && categoriaarma != '3');

        do {
            System.out.printf("\n===================\n");
            System.out.printf("  (1) Uniforme 1\n");
            System.out.printf("  (2) Uniforme 2\n");
            System.out.printf("===================\n");
            System.out.printf("\nEscolha seu uniforme:");
            categoriaarmadura = scanner.next().charAt(0);
            categoriaarmadura = Character.toUpperCase(categoriaarmadura);
            // Converte para maiúsculas para consistência  

            if (1 == categoriaarmadura) {
                armadura.calculararmadura();

            } else if (2 == categoriaarmadura) {
                armadura.calculararmadura();
            }

        } while (categoriaarmadura != '1' && categoriaarmadura != '2');

        return new Personagem(nome, forca, defesa, agilidade, destreza, categoriaarma, categoriaarmadura);
    }

    private Inimigo inimigoAleatorio(Personagem personagem, int nivel) {
        Inimigo inimigo;
        int escolhaInimigo;

        switch (nivel) {
            case 1:
                escolhaInimigo = random.nextInt(3); // Escolhe entre os 3 tipos de inimigos
                switch (escolhaInimigo) {
                    case 0 -> {
                        inimigo = new Curupira();
                        System.out.println(" =====================================================================================================================");
                        System.out.println("||  pensava que depois do que tudo que aconteseu na minha vida nos utimos tem pos e com a descobretas de certos      ||");
                        System.out.println("||  segedos pensava que ira fivalmete ter um seta nomaliddae mais logo nas primera semanas des do comes das aluas    ||");
                        System.out.println("||  a Anillusnus fica bobre ataque de uma misteriosa figuara  que tem sobra seu com trole toda os seres sobrenatura  ||");
                        System.out.println("||  que deram orige as lemdas brasileras.augus dos alunos consegiram fugir logo no comeso de tudo, mais uma grade    ||");
                        System.out.println("||  patae esta entando acha seu propio caminho nomeio de todo esse caos , aissim como eu  nesse moneto.              ||");
                        System.out.println("||  desido que agora vai temtar vira a esquerda e temtra a porxima porta a direta , aism se deparando com um ser     ||");
                        System.out.println("||  de pele de tom terroso, cabelos vermelhos que pareciam ser feitos de folhas secas e galhos retorcidos, e seus    ||");
                        System.out.println("||  olhos brilhavam com a energia das florestas antigas e com um bilho seuvagem. seus pés eram retosidoa totalmente  ||");
                        System.out.println("||  para tas e fasilmete enganaria algem sober onde ele esteve se so vise assua pegadas, a sua fente estava o tam    ||");
                        System.out.println("||  temido Curupira!!!                                                                                               ||");
                        System.out.println(" =====================================================================================================================");
                    }
                    case 1 -> {
                        inimigo = new SaciPerere();
                        System.out.println(" =====================================================================================================================");
                        System.out.println("||  pensava que depois do que tudo que aconteseu na minha vida nos utimos tem pos e com a descobretas de certos      ||");
                        System.out.println("||  segedos pensava que ira fivalmete ter um seta nomaliddae mais logo nas primera semanas des do comes das aluas    ||");
                        System.out.println("||  a Anillusnus fica bobre ataque de uma misteriosa figuara  que tem sobra seu com trole toda os seres sobrenatura  ||");
                        System.out.println("||  que deram orige as lemdas brasileras.augus dos alunos consegiram fugir logo no comeso de tudo, mais uma grade    ||");
                        System.out.println("||  patae esta entando acha seu propio caminho nomeio de todo esse caos , aissim como eu  nesse moneto.              ||");
                        System.out.println("||  Decido que agora vou tentar virar à esquerda e tentar a próxima porta à direita, quando, de repente, me deparo   ||");
                        System.out.println("||  com um ser estranho. Ele tinha uma perna só e um gorro vermelho na cabeça ,ele  saltitava com sua perna so e em  ||");
                        System.out.println("||sua cora tinha um cachibo que sai fumasa que se espalava por toda pate,a sua fente estava o tao  temido Saci-Pererê||");
                        System.out.println(" =====================================================================================================================");
                    }
                    default -> {
                        inimigo = new Boto();
                        System.out.println(" =========================================================================================================================");
                        System.out.println("||  Eu pensava que, depois de tudo o que aconteceu na minha vida nos últimos tempos e com a descoberta de certos         ||");
                        System.out.println("||  segredos, finalmente teria uma vida normal. Mas logo nas primeiras semanas desde o início das aulas, a Anillusnus    ||");
                        System.out.println("||  foi atacada por uma misteriosa figura que exercia controle sobre todas as criaturas sobrenaturais que deram origem   ||");
                        System.out.println("||  às lendas brasileiras. Alguns dos alunos conseguiram fugir logo no começo de tudo, mas uma grande parte está tentando||");
                        System.out.println("||  encontrar seu próprio caminho em meio a todo esse caos, assim como eu neste momento.                                 ||");
                        System.out.println("||  Decido que agora vou tentar virar à esquerda e tentar a próxima porta à direita, quando, de repente, me deparo      ||");
                        System.out.println("||  com um homem extremamente atraente, com uma pele bronzeada e cabelos negros e sedosos. Seus olhos eram               ||");
                        System.out.println("|| profundamente hipnotizantes, com um brilho inquietante,como se escondessem segredos profundos. e ele se vestia com    ||");
                        System.out.println("|| espetacula terno italiano branco e um chapéu panamá branco, logo  o vi tive ser tesa na mina fente esta o Boto        ||");
                        System.out.println("||  gentileza profunda. Ele exala uma aura de mistério e sedução, enquanto a água escorre de sua pele imaculada.         ||");
                        System.out.println("||  O Boto é conhecido por sua beleza irresistível e por sua habilidade de seduzir os incautos, e sua presença           ||");
                        System.out.println("||  acrescenta uma aura de fascinação e perigo a esta situação já caótica.                                               ||");
                        System.out.println(" =========================================================================================================================");
                    }
                }
                break;

            case 2:
                escolhaInimigo = random.nextInt(2); // Escolhe entre 2 tipos de inimigos
                switch (escolhaInimigo) {
                    case 1 ->
                        inimigo = new Iara();

                    default -> {
                        inimigo = new Boitata();
                        System.out.println(" =========================================================================================================================");
                        System.out.println("||  Eu pensava que, depois de tudo o que aconteceu na minha vida nos últimos tempos e com a descoberta de certos         ||");
                        System.out.println("||  segredos, finalmente teria uma vida normal. Mas logo nas primeiras semanas desde o início das aulas, a Anillusnus    ||");
                        System.out.println("||  foi atacada por uma misteriosa figura que exercia controle sobre todas as criaturas sobrenaturais que deram origem   ||");
                        System.out.println("||  às lendas brasileiras. Alguns dos alunos conseguiram fugir logo no começo de tudo, mas uma grande parte está tentando||");
                        System.out.println("||  encontrar seu próprio caminho em meio a todo esse caos, assim como eu neste momento.                                 ||");
                        System.out.println("||  Decido que agora vou tentar virar à esquerda e tentar a próxima porta à direita, quando, de repente, me deparo      ||");
                        System.out.println("|| se deparo com um homem extremamente atraente, com uma pele bronzeada e cabelos negros e sedosos. Seus olhos eram      ||");
                        System.out.println("|| profundamente hipnotizantes, com um brilho inquietante,como se escondessem segredos profundos. e ele se vestia com    ||");
                        System.out.println("|| espetacula terno italiano branco e um chapéu panamá branco, logo  o vi tive ser tesa na mina fente esta o Boto        ||");
                        System.out.println(" =========================================================================================================================");
                    }
                }
                break;

            case 3:
                //escolha somente a mula sem cabeça
                inimigo = new MulaSemCabeca();
                  System.out.println(" =========================================================================================================================");
        System.out.println("||  Eu pensava que, depois de tudo o que aconteceu na minha vida nos últimos tempos e com a descoberta de certos         ||");
        System.out.println("||  segredos, finalmente teria uma vida normal. Mas logo nas primeiras semanas desde o início das aulas, a Anillusnus    ||");
        System.out.println("||  foi atacada por uma misteriosa figura que exercia controle sobre todas as criaturas sobrenaturais que deram origem   ||");
        System.out.println("||  às lendas brasileiras. Alguns dos alunos conseguiram fugir logo no começo de tudo, mas uma grande parte está tentando||");
        System.out.println("||  encontrar seu próprio caminho em meio a todo esse caos, assim como eu neste momento.                                 ||");
        System.out.println("||  Decido que agora vou tentar virar à esquerda e tentar a próxima porta à direita, quando, de repente, me deparo com   ||");
        System.out.println("||  uma mula so que envesde sua cabeça avia chamas,ardentes e bilhantes de on de deveria esta . nasua fente estva a      ||");
        System.out.println("||  Mula Sem Cabeça!!!!!                                                                                                 ||");
        System.out.println(" =========================================================================================================================");

                break;

            default:
                inimigo = null; // Lidar com o caso de nível inválido (se necessário)
                break;
        }

        return inimigo;
    }

    private int lerInteiro() {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.printf("Escolha: ");
            while (!scanner.hasNextInt()) {
                System.out.printf("Entrada inválida. Por favor, digite um número.");
                System.out.printf("Escolha: ");
                scanner.next(); // Limpa o buffer do scanner
            }
            int escolha = scanner.nextInt();
            return escolha;
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Digite um número válido.");
            return lerInteiro(); // Recursivamente tente novamente
        }
    }

}
