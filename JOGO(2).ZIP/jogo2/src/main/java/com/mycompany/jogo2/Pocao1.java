/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jogo2;

/**
 *
 * @author silva
 */import java.util.Random;
public class Pocao1 {
    private String nome;
    private int cura;
    private int usarPocao;

   
    public Pocao1(String nome,int cura){
    this.nome=nome;
    this.cura=cura;
}
     private Random random = new Random();

    public int usarPocao() {
      
        int cura =  usarPocao;
                cura = random.nextInt(6) + 1 + random.nextInt(6) + 1 + random.nextInt(6) + 1;
        return cura;
    }
    public int getusarPocao() {
        cura =  usarPocao;
       return cura;
    }

    
}


