package com.mycompany.jogo2;

import java.util.InputMismatchException;
import java.util.Random;

/**
 *
 * @author yslan
 */
class Inimigo {

    private String nome;
    private int pontosDeVida;
    private int dano;
    private int defesa;
    private int agilidade;

    private static final int VIDA_MAXIMA = 70; // Limite de vida máxima
    private int calcularDano;

    public Inimigo(String nome, int pontosDeVida, int dano, int defesa, int agilidade) {
        this.nome = nome;
        this.pontosDeVida = pontosDeVida;
        this.dano = dano;
        this.defesa = defesa;
        this.agilidade = agilidade;
    }

    public String getNome() {
        return nome;
    }

    public int getPontosDeVida() {
        return pontosDeVida;
    }

    public int getDano() {
        return dano;
    }

    public int Dano() {
        int Dano = calcularDano(); // Use o método que você já tem para calcular o dano.
        System.out.println(getNome() + " ataca e causa " + dano + " pontos de dano!");
        return dano;
    }

    private int calcularPontosDeVida() {
        Random random = new Random();
        int pontosDeVidaCalculados = random.nextInt(3) + 1; // Exemplo de cálculo aleatório, ajuste conforme necessário

        // Limita a vida máxima a 78
        return Math.min(pontosDeVidaCalculados, VIDA_MAXIMA);
    }

    public int getDefesa() {
        return defesa;
    }

    public int getAgilidade() {
        return agilidade;
    }

    int Defesa() {
        return (int) (1.5 * defesa);
    }

    void setPontosDeVida(int pontosDeVida) {
        this.pontosDeVida = pontosDeVida;
    }

    public int getVidaMaxima() {
        return VIDA_MAXIMA;
    }

    int getcalcularDano() {
        return calcularDano;
    }

    int calcularDano() {
        return calcularDano;
    }
}

class MulaSemCabeca extends Inimigo {

    public MulaSemCabeca() {
        super("Mula Sem Cabeça", 40, 25, 20, 8);
    }
}

class SaciPerere extends Inimigo {

    public SaciPerere() {
        super("Saci-Pererê", 20, 10, 8, 5);
    }
}

class Curupira extends Inimigo {

    public Curupira() {
        super("Curupira", 25, 8, 5, 4); // Nome, Pontos de Vida, Dano, Defesa, Agilidade
    }
}

class Boitata extends Inimigo {

    public Boitata() {
        super("Boitatá", 35, 15, 15, 5); // Nome, Pontos de Vida, Dano, Defesa, Agilidade
    }
}

class Iara extends Inimigo {

    public Iara() {
        super("Iara", 28, 10, 18, 12); // Nome, Pontos de Vida, Dano, Defesa, Agilidade
    }
}

class Boto extends Inimigo {

    public Boto() {
        super("Boto", 26, 9, 7, 5); // Nome, Pontos de Vida, Dano, Defesa, Agilidade
    }

}
