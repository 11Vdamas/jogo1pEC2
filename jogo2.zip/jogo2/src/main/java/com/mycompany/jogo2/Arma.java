package com.mycompany.jogo2;

import java.util.Random;

class Arma {

    private Personagem personagem;
    private String nome;
    String categoriaarma;
    private int constantedano = 4;
    private int forca;
    private int pontosDestreza;

    public Arma(String nome, String categoriaarma, int contantedano, int forca, int pontosDestreza) {
        this.nome = nome;
        this.categoriaarma = categoriaarma;
        this.constantedano = constantedano;
        this.forca = forca;
        this.pontosDestreza = pontosDestreza;

    }

    public int calcularDanoCajado() {
        Random rand = new Random();
        int d12 = rand.nextInt(12) + 1; // Rolagem de um d12 (números de 1 a 12)
        double danoPesado = d12 + (1.5 * personagem.getForca()) + constantedano;
        return (int) danoPesado; // Converter para int, se necessário
    }

    public int calcularDanoVarinha() {
        Random rand = new Random();
        int d61 = rand.nextInt(6) + 1;
        int d62 = rand.nextInt(6) + 1;
        int d4 = rand.nextInt(4) + 1;
        int danoleve = d61 + d62 + d4 + personagem.getDestreza()+ constantedano;
        return danoleve; // Converter para int, se necessário//
    }

    public int calcularDanoEscova() {
        Random rand = new Random();
        int d61 = rand.nextInt(6) + 1;
        int d62 = rand.nextInt(6) + 1;
        int d4 = rand.nextInt(4) + 1;
        int danoleve = d61 + d62 + d4 + personagem.getDestreza() + constantedano;
        return danoleve; // Converter para int, se necessário//
    }
}
