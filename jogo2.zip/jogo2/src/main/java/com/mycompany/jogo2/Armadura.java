package com.mycompany.jogo2;

import java.util.Random;

/**
 *
 * @author yslan
 */
class Armadura {

    private Personagem personagem;
    private String nome;
    private String categoriaarmadura;
    private final int armadura;
    int defesadaarmadura;
    private int constantedefesa = 1;

    public Armadura(String nome, String categoriaarmadura, int armadura, int defesadaarmadura, int constantedefesa) {
        this.nome = nome;
        this.categoriaarmadura = categoriaarmadura;
        this.armadura = armadura;
        this.defesadaarmadura = defesadaarmadura;
        this.constantedefesa = constantedefesa;

    }

    public int calculararmadura() {
        //Random rand = new Random();
        //int d61 = rand.nextInt(6) + 1; // Rolagem de um d6 (números de 1 a 6)
        //int d62 = rand.nextInt(6) + 1; // Rolagem de um d6 (números de 1 a 6)
        //int d63 = rand.nextInt(6) + 1; // Rolagem de um d6 (números de 1 a 6)
        double defesadaarmadura = constantedefesa + (1.5 * personagem.getDefesa());
        return (int) defesadaarmadura; // Converter para int, se necessário
    }

    int getarmadura() {
       
        return defesadaarmadura;
    }

    int setarmadura() {
       
        return defesadaarmadura;
    }

}
